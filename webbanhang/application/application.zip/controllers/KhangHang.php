<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class KhangHang extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		
	}

}

/* End of file KhangHang.php */
/* Location: ./application/controllers/KhangHang.php */