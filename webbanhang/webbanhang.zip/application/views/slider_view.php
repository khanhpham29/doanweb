<!-- slider -->
    <main class="main">
      <div class="container">
        <div class="flash-sale-header-with-countdown-timer__header"></div>
        <div id="wp-slider">					
					<div class="items-slide">
						<div class="owl-carousel owl-theme">
              <div class="item">
                <figure class="clearfix">
                  <div class="sanpham">
                    <a href="iphone7.html">
                      <img src="<?php echo base_url() ?>vendor/images/sanpham/1.jpg" alt="" style="display:inline;">
                    </a>
                  </div>
                  <figcaption>
                    <h3>
                      <a href="iphone7.html">
                        IPHONE 7 PLUS 128GB BLACK
                      </a>
                    </h3>
                    <strike>13.500.000</strike>
                    <strong>12.990.000₫</strong>
                  </figcaption>
                </figure>
              </div>                          
						</div>
					</div>				
				</div>
      </div>
    </main>
    <!-- /slider -->