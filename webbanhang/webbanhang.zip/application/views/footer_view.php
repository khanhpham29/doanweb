<div class="tygh-footer clearfix"> 
      <div class="container">
        <div class="row">
          <div class="col-md-3"> 
            <ul>
              <li><a href=""><b>Hỗ trợ khách hàng</b></a></li>
              <li><a href="">Hướng dẫn mua hàng</a></li>
              <li><a href="">Hình thức thanh toán</a></li>
              <li><a href="">Tra cứu bảo hành</a></li>
              <li><a href="">Ưu đãi ngân hàng</a></li>
              <li><a href="">Trả góp</a></li>
            </ul>
          </div>
          <div class="col-md-3"> 
            <ul>
              <li><a href=""><b>Cách thức mua hàng</b></a></li>
              <li>
                <a href="">Bảo hành & khiếu nại </a>
                <a href="tel:19006612">
                  <strong class="hot-line">1900.6612</strong>
                </a>
              </li>
              <li>
                <a href="">Tổng đài mua hàng </a>
                <a href="tel:19006612">
                    <strong class="hot-line">1900.1267</strong>
                </a>
              </li>
              <li><a href="">Nhận hàng tại nhà</a></li>
              <li><a href="">Nhận hàng tại cửa hàng</a></li>
            </ul>
          </div>
          <div class="col-md-4"> 
              <h3>Phương thức thanh toán</h3>
              <ul>
                <li>
                  <i class="nk-sprite-fcon nkfcon-visa"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-mastercard"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-atm"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-jcb"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-cod"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-installment"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-zalo-pay"></i>
                </li>
                <li>
                  <i class="nk-sprite-fcon nkfcon-momo"></i>
                </li>
              </ul>
          </div>
        </div>
        <hr class="foot-line">
        <div class="row">
          <div class="col-md-8">
            <h1><span>STUSROTE - ĐỒ ÁN VỀ CỬA HÀNG ĐIỆN MÁY TRỰC TUYẾN UY TÍN GIÁ TỐT HÀNG ĐẦU VIỆT NAM</span></h1>
            <span>Mã số thẻ sinh viên mã DH51704012 do trường ĐẠI HỌC CÔNG NGHỆ SÀI GÒN cấp. Lớp mã D17_TH08 do Khoa Công Nghệ Thông tin STU quy định. Địa chỉ: 180 Cao Lỗ, Phường 4, Quận 8, Tp. Hồ Chí Minh, Điện thoại: 1900 1267 <br> Email: pdmquan@gmail.com. Copyright © 2017 - 2019 ĐỒ ÁN NHẬP MÔN LẬP TRÌNH WEB, hiện chưa cấp bản quyền.</span>
          </div>
          <div class="col-md-4">
            <div class="logofooter">  
              <ul>
                <li><a href=""><i class="nk-sprite-fcon nkfcon-da-dang-ky-bo-cong-thuong"></i></a></li>
                <li><a href=""><i class="nk-sprite-fcon nkfcon-da-thong-bao-bo-cong-thuong"></i></a></li>
                <li><a href=""><i class="nk-sprite-fcon nkfcon-protected-by-copyscape"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <hr>